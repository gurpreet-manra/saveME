//
//  ProfileEdit.swift
//  SafetyApp
//
//  Created by Guneet Singh on 2018-07-25.
//  Copyright © 2018 Guneet Singh. All rights reserved.
//

import Foundation
import UIKit
import CoreData
import Firebase
import FirebaseDatabase



class ProfileView: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate
{
    
    @IBOutlet weak var imgPick2: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBAction func editButton(_ sender: Any) {
    }
    @IBAction func logoutButton(_ sender: Any) {
        
            do{
                try Auth.auth().signOut()
            } catch let logoutErr {
                print(logoutErr)
            }
        let vc = self.storyboard!.instantiateViewController(withIdentifier: "firstviewcontroller") 
        //  self.tabBarController?.present(vc, animated: true, completion: nil)
        self.present(vc, animated: true, completion: nil)
        print("logout")
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        imgPick2.layer.cornerRadius = imgPick2.frame.size.width/2
        imgPick2.clipsToBounds = true
        
        
        checkLogin()
    }
    func checkLogin(){
    if Auth.auth().currentUser?.uid == nil {
        print("there is a problem")
    performSelector(inBackground: #selector(handleLogout), with: nil)
    } else {
        let uid = Auth.auth().currentUser?.uid
        Database.database().reference(fromURL: "https://saveme-6980a.firebaseio.com/").child("Users").child(uid!).observe(.value, with: { (snapshot) in
            if let dictionary = snapshot.value as? [String: AnyObject]{
                self.nameLabel.text = dictionary["name"] as? String
                
                if let profileImageUrl = dictionary["profileImageUrl"] as? String {
                    let url = URL(string: profileImageUrl)
                 
                    URLSession.shared.dataTask(with: url!) { (data, response, error) in
                        if error != nil{
                            print(error)
                            return
                        }
                        //  DispatchQueue.main.async(execute: DispatchQueue.main())
                        DispatchQueue.main.async {
                            self.imgPick2?.image = UIImage(data: data!)
                        }
                        
                        }.resume()
                }
            }
        }, withCancel: nil)
        }
    }
    @objc func handleLogout(){
        do{
            try Auth.auth().signOut()
        } catch let logoutErr {
            print(logoutErr)
        }
        
        print("problem second")
        let vc = self.storyboard!.instantiateViewController(withIdentifier: "firstviewcontroller") as! UIViewController
        //  self.tabBarController?.present(vc, animated: true, completion: nil)
        self.present(vc, animated: true, completion: nil)
    }
    
}
