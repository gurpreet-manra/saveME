//
//  ProfileVC.swift
//  SafetyApp
//
//  Created by Guneet Singh on 2018-07-06.
//  Copyright © 2018 Guneet Singh. All rights reserved.
//

import Foundation
import UIKit
import CoreData
import Firebase
import FirebaseDatabase


class ProfileVC: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITextFieldDelegate
{
    override func viewDidLoad() {
        super.viewDidLoad()
        ref = Database.database().reference(fromURL: "https://saveme-6980a.firebaseio.com/")
        
        imgPick.layer.cornerRadius = imgPick.frame.size.width/2
        imgPick.clipsToBounds = true
        self.name.delegate = self
        self.password.delegate = self
        self.email.delegate = self
        self.phoneNumber.delegate = self
    }
    
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var imgPick: UIImageView!
    @IBOutlet weak var name: UITextField!
    @IBOutlet weak var phoneNumber: UITextField!
    @IBOutlet weak var email: UITextField!
    @IBAction func saveInfo(_ sender: Any) {
        
        guard let email = email.text, let password = password.text, let name = name.text, let phone = phoneNumber.text else {
            print("form is not valid")
            return
        }
        if name == "" || phone == "" || email == "" || password == ""
        {
            let alert = UIAlertController(title: "Something is Missing", message: "Please enter all the required information", preferredStyle: .alert)
            let action = UIAlertAction(title: "Ok, let me try again!", style: .default, handler: nil)
            alert.addAction(action)
            present(alert, animated: true, completion: nil)
        }
        else if phone.count < 10
            {
                    let alert = UIAlertController(title: "Invalid Phone Number", message: "Please Enter a Valid Phone number", preferredStyle: .alert)
                    let action = UIAlertAction(title: "Ok thanks", style: .default, handler: nil)
                    alert.addAction(action)
                    present(alert,animated: true, completion: nil)
            }
        else if email.range(of: "@") == nil
        {
            let alert = UIAlertController(title: "Invalid Email address", message: "Please Enter a Valid Email address", preferredStyle: .alert)
            let action = UIAlertAction(title: "Ok thanks", style: .default, handler: nil)
            alert.addAction(action)
            present(alert,animated: true, completion: nil)
        }
        else if password.count < 6
        {
            let alert = UIAlertController(title: "Invalid Password Length", message: "Please create password with atleast 8 characters", preferredStyle: .alert)
            let action = UIAlertAction(title: "Ok thanks", style: .default, handler: nil)
            alert.addAction(action)
            present(alert,animated: true, completion: nil)
        }
        Auth.auth().createUser(withEmail: email, password: password) { (authResult, error) in
            if error != nil {
                print(error)
                return
            }
            guard let uid = authResult?.user.uid else {
                return
            }
           // let imageName = UUID().uuidString
            let storageRef = Storage.storage().reference().child("profile_images").child("\(uid).png")
            
           // let storageRef = Storage.storage().reference().child("Images").child("\(uid).png")
            let currentId = uid
            if let uploadData = UIImagePNGRepresentation(self.imgPick.image!){
                
                storageRef.putData(uploadData, metadata: nil) { (metadata, error) in
                      if error != nil {
                     print(error)
                     return
                     }
                    
                    storageRef.downloadURL(completion: { (url, error) in
                        if let urlText = url?.absoluteString {
                            let uid = authResult?.user.uid
                           // self.strURL = urlText
                            //print(self.strURL)
                            let value = ["name": name, "email": email, "contact": phone, "profileImageUrl": urlText] as [String:AnyObject]
                            self.handleRegisterWithUID(uid: uid!, values: value)
                            //completion(strURL)
                        }
                    })
                   // print(metadata)
                }
            }
        }
        
    }
    private func handleRegisterWithUID(uid:String, values: [String: AnyObject]){
        let ref =  Database.database().reference(fromURL: "https://saveme-6980a.firebaseio.com/")
        let profileRefrence = ref.child("Users").child(uid)
        //let values = ["name": newname, "email": newemail, "contact": newphone, "profileImageUrl": strURL!]
        
        print("hellolljbcj")
      //  print(strURL)
        profileRefrence.updateChildValues(values, withCompletionBlock: { (err, ref) in
            if err != nil {
                print(err)
                return
            }
            print(" user saved")
            let vc = self.storyboard!.instantiateViewController(withIdentifier: "viewcontroller") as! UITabBarController
            //  self.tabBarController?.present(vc, animated: true, completion: nil)
            self.present(vc, animated: true, completion: nil)        })
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        name.resignFirstResponder()
        email.resignFirstResponder()
        password.resignFirstResponder()
        phoneNumber.resignFirstResponder()
        return true
    }
    @IBAction func chooseImage(_ sender: Any) {
        let imagePickerController = UIImagePickerController()
        imagePickerController.delegate = self
        
        let actionSheet = UIAlertController(title: "Photo Source", message: "Choose a Source", preferredStyle: .actionSheet)
        actionSheet.addAction(UIAlertAction(title: "Camera", style: .default, handler: { (action: UIAlertAction) in
            if UIImagePickerController.isSourceTypeAvailable(.camera)
            {
                imagePickerController.sourceType = .camera
            self.present(imagePickerController, animated: true, completion: nil)
            }
                else
                {
                    print("Camera not available")
                }
        }))
        actionSheet.addAction(UIAlertAction(title: "Photo Library", style: .default, handler: { (action: UIAlertAction) in
            imagePickerController.sourceType = .photoLibrary
            self.present(imagePickerController, animated: true, completion: nil)
        }))
        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .default, handler: { (action: UIAlertAction) in }))
        
        self.present(actionSheet, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String: Any]) {
        
        let image = info[UIImagePickerControllerOriginalImage] as! UIImage
        imgPick.image = image
        picker.dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

}
