//
//  ContactVC.swift
//  SafetyApp
//
//  Created by Guneet Singh on 2018-07-06.
//  Copyright © 2018 Guneet Singh. All rights reserved.
//

import Foundation
import UIKit
import Firebase
import FirebaseDatabase

class ContactVC: UIViewController, UITextFieldDelegate
{
    
    @IBOutlet weak var ShowContacts: UILabel!
    @IBOutlet weak var contactText: UITextField!
    
    var contacts = [String]()
    let cellId = "cellId"
    var show = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        self.contactText.delegate = self
       // ref = Database.database().reference(fromURL: "https://saveme-6980a.firebaseio.com/")
        let uid = Auth.auth().currentUser?.uid
        Database.database().reference(fromURL: "https://saveme-6980a.firebaseio.com/").child("Contacts").child(uid!).child("userContacts").observe(.childAdded) { (snapshot) in
            
            if let dictionary = snapshot.value as? [String: AnyObject] {
                let contact = dictionary["emergencyPhone"] as? String
               // print(contact)
                self.contacts.append(contact!)
                print("here")
                print(self.contacts)
       
            }
             self.showContact()
        }

    }
    @IBOutlet weak var messageText: UITextField!
    
    
    @IBAction func addButton(_ sender: Any) {
        
        guard let uid = Auth.auth().currentUser?.uid else {
            return
        }
        let ref = Database.database().reference(fromURL: "https://saveme-6980a.firebaseio.com/")
        let thisUsersGamesRef = ref.child("Contacts").child(uid).child("userContacts")
        
        let gameRef0 = thisUsersGamesRef.childByAutoId().child("emergencyPhone")
        gameRef0.setValue(contactText.text)
        print("Contact Saved")
   
    }
    
    @IBAction func deleteButton(_ sender: Any) {
        
        
        
    }
    
    
    func showContact(){
        var a = ""
        
        for i in 0..<self.contacts.count {
            a = contacts[i]
        }
        
        self.show += "\n"
        self.show += a
        self.ShowContacts.text = self.show
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
         contactText.resignFirstResponder()
        return true
    }
    
}
