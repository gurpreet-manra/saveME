//
//  FirstScreen.swift
//  SafetyApp
//
//  Created by Guneet Singh on 2018-07-25.
//  Copyright © 2018 Guneet Singh. All rights reserved.
//

import Foundation
import UIKit
import CoreData
import Firebase
import FirebaseDatabase

class FirstVC: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITextFieldDelegate
{
 
    @IBOutlet weak var emailFVC: UITextField!
    
    @IBOutlet weak var passwordFVC: UITextField!
    @IBAction func SigninButton(_ sender: Any) {
        
        guard let email = emailFVC.text, let password = passwordFVC.text else {
            print("form is not valid")
            return
        }
        Auth.auth().signIn(withEmail: email, password: password) { (user, error) in
            if error != nil {
                let alert = UIAlertController(title: "Account not Found", message: "Please enter valid account info or Sign Up if you are new. ", preferredStyle: .alert)
                let action = UIAlertAction(title: "Alright,Thanks", style: .default, handler: nil)
                alert.addAction(action)
                self.present(alert, animated: true, completion: nil)
                print(error)
                return
            }
            print("Signed in")
        
            let vc = self.storyboard!.instantiateViewController(withIdentifier: "viewcontroller") as! UITabBarController
          //  self.tabBarController?.present(vc, animated: true, completion: nil)
            self.present(vc, animated: true, completion: nil)
    
        }
        if emailFVC.text != "" && passwordFVC.text == ""
        {
            let alert = UIAlertController(title: "Cannot Sign In", message: "Please enter something in password to Sign In", preferredStyle: .alert)
            let action = UIAlertAction(title: "Alright,Thanks", style: .default, handler: nil)
            alert.addAction(action)
            present(alert, animated: true, completion: nil)
        }
        else if emailFVC.text == "" && passwordFVC.text != ""
        {
            let alert = UIAlertController(title: "Cannot Sign In", message: "Please enter something in Email to Sign In", preferredStyle: .alert)
            let action = UIAlertAction(title: "Alright,Thanks", style: .default, handler: nil)
            alert.addAction(action)
            present(alert, animated: true, completion: nil)
        }
    }
    
    @IBAction func signoutButton(_ sender: Any) {
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.emailFVC.delegate = self
        self.passwordFVC.delegate = self
        if Auth.auth().currentUser?.uid == nil {
            performSelector(inBackground: #selector(handleLogout), with: nil)
        } else {
            let vc = self.storyboard!.instantiateViewController(withIdentifier: "viewcontroller") as! UITabBarController
            //  self.tabBarController?.present(vc, animated: true, completion: nil)
            self.present(vc, animated: true, completion: nil)
        }
       
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if Auth.auth().currentUser != nil {
            let vc = self.storyboard!.instantiateViewController(withIdentifier: "viewcontroller") as! UITabBarController
            //  self.tabBarController?.present(vc, animated: true, completion: nil)
            self.present(vc, animated: true, completion: nil)
        }
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        emailFVC.resignFirstResponder()
        passwordFVC.resignFirstResponder()
        return true
    }

    @objc func handleLogout(){
        do{
            try Auth.auth().signOut()
        } catch let logoutErr {
            print(logoutErr)
        }
        
    }
    
}
