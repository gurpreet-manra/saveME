//
//  MainVC.swift
//  SafetyApp
//
//  Created by Guneet Singh on 2018-07-29.
//  Copyright © 2018 Guneet Singh. All rights reserved.
//

import Foundation
import UIKit
import MessageUI
import MapKit
import CoreLocation
import Firebase
import FirebaseDatabase

class MainVC: UIViewController, MFMessageComposeViewControllerDelegate, CLLocationManagerDelegate {
    var contacts = [String]()
    var latitudeString: String = ""
    var longitudeString: String = ""
    
    let locationManager = CLLocationManager()
    var previousPoint: CLLocation? = nil
    var totalMovementDistance = CLLocationDistance(0)
  
    @IBAction func callButton(_ sender: Any) {
        if let url = URL(string: "tel://(+16479790790)") {
            if UIApplication.shared.canOpenURL(url) {
                UIApplication.shared.open(url, options: [:], completionHandler: nil)
            }
            else
            {
                print("This device does not have call functionality")
            }
        }
    }
    @IBAction func sendSMS(_ sender: Any) {
    
        if MFMessageComposeViewController.canSendText()
        {
      
            let controller = MFMessageComposeViewController()
            controller.body = "Hello I Need Help at This Location \n http://maps.apple.com/?daddr=\(latitudeString),\(longitudeString)"
            
            controller.recipients = contacts
            controller.messageComposeDelegate = self
            self.present(controller, animated: true, completion: nil)
        }
        else
        {
            print("Test..!!")
        }
    }
   
    override func viewDidLoad() {
        super.viewDidLoad()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestWhenInUseAuthorization()
        let uid = Auth.auth().currentUser?.uid
        let reff = Database.database().reference(fromURL: "https://saveme-6980a.firebaseio.com/")
       reff.child("Contacts").child(uid!).child("userContacts").observe(.childAdded) { (snapshot) in
            
            if let dictionary = snapshot.value as? [String: AnyObject] {
                let contact = dictionary["emergencyPhone"] as? String
                // print(contact)
                self.contacts.append(contact!)
              
            }
        }
        
    }
    
    func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult) {
        
        self.dismiss(animated: true, completion: nil)
    }
    
  
    func locationManager(_ manager: CLLocationManager,
                         didChangeAuthorization status: CLAuthorizationStatus) {
        print("Authorization status changed to \(status.rawValue)")
        switch status {
        case .authorizedAlways, .authorizedWhenInUse:
            locationManager.startUpdatingLocation()
        //mapView.showsUserLocation = true
        default:
            locationManager.stopUpdatingLocation()
            //mapView.showsUserLocation = false
        }
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let newLocation = locations.last
        {
             latitudeString = String(format: "%g\u{00B0}",newLocation.coordinate.latitude)
            //                latitudeLabel.text = latitudeString
            //                latitudeLabel.text = latitudeString
            print(latitudeString)
            
             longitudeString = String(format: "%g\u{00B0}",
                                         newLocation.coordinate.longitude)
            //                longitudeLabel.text = longitudeString
            print(longitudeString)
        }
    }
    
    
}
