//
//  ViewController.swift
//  SafetyApp
//
//  Created by Guneet Singh on 2018-07-06.
//  Copyright © 2018 Guneet Singh. All rights reserved.
//

import UIKit
import MessageUI
import MapKit
import CoreLocation
import Firebase
import FirebaseDatabase

class ViewController: UITabBarController//, MFMessageComposeViewControllerDelegate
{
    
    override func viewDidLoad() {
        super.viewDidLoad()
     
        if Auth.auth().currentUser?.uid == nil {
            performSelector(inBackground: #selector(handleLogout), with: nil)
        }
        
    }
    
    @objc func handleLogout(){
        do{
            try Auth.auth().signOut()
        } catch let logoutErr {
            print(logoutErr)
        }
        let vc = self.storyboard!.instantiateViewController(withIdentifier: "firstviewcontroller") 
        //  self.tabBarController?.present(vc, animated: true, completion: nil)
        self.present(vc, animated: true, completion: nil)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult) {

        self.dismiss(animated: true, completion: nil)
    }
    
   
    }


